# NickUI
[![](https://poggit.pmmp.io/shield.state/NickUI)](https://poggit.pmmp.io/p/NickUI)
<a href="https://poggit.pmmp.io/p/NickUI"><img src="https://poggit.pmmp.io/shield.state/NickUI"></a>

[![](https://poggit.pmmp.io/shield.api/NickUI)](https://poggit.pmmp.io/p/NickUI)
<a href="https://poggit.pmmp.io/p/NickUI"><img src="https://poggit.pmmp.io/shield.api/NickUI"></a>

# Description
• This Plugin is NickName UI plugin for pocketmine!

# Commands
• /nick

# Permissions
• danuroyt.nick

# Owner
• The Owner of this plugin is DanuRoYT

• Add me on discord to chat with me! DanuRoYT#1854

# LICENSE

The License is here [License](LICENSE)
