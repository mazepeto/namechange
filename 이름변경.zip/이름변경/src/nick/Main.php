<?php

namespace nick;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {
	
	private $nickcfg;
	
	public function onEnable(){
		$this->nickcfg = new Config($this->getDataFolder() . "nicks.yml", Config::YAML);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function onQuit(PlayerQuitEvent $ev){
		$player = $ev->getPlayer();
		
		if(!$this->nickcfg->exists($player->getName())){
			return true;
		}
		
		if($this->nickcfg->exists($player->getName())){
			$this->nickcfg->remove($player->getName());
			$this->nickcfg->save();
			return true;
		}
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
		
		switch($cmd->getName()){
			case "이름":
			if(!($sender->hasPermission("danuroyt.nick"))){
				$sender->sendMessage("§c권한이 없습니다");
				return true;
			}
			if(!($sender instanceof Player)){
				$sender->sendMessage("§c게임내에서만 사용가능합니다");
				return true;
			}
			$form = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $player, $data = null){
				$result = $data;
				if($result === null){
					return true;
				}
				switch($result){
					case 0;
					$this->changenick($player);
					break;
					case 1;
					if(!$this->nickcfg->exists($player->getName())){
						$player->sendMessage("§c이름을 바꿀 수 없습니다");
						return true;
					}
					if($this->nickcfg->exists($player->getName())){
						$player->setNameTag($this->nickcfg->getNested($player->getName() . ".normal name"));
						$player->setDisplayName($this->nickcfg->getNested($player->getName() . ".normal name"));
						$this->nickcfg->remove($player->getName());
						$this->nickcfg->save();
						$player->sendMessage("§6기본으로 변경되었습니다");
						return true;
					}
					break;
				}
			});
			$form->setTitle("§3닉네임");
			if($this->nickcfg->exists($sender->getName())){
			$form->setContent("§a당신의 이름을 바꾸세요 \n§e당신의 이름은" . $this->nickcfg->getNested($sender->getName() . ".custom name"));
			}
			if(!$this->nickcfg->exists($sender->getName())){
			$form->setContent("§a당신의 이름을 바꿨습니다\n\n§6이름이 없습니다.");
			}
			$form->addButton("§e이름바꾸기");
			$form->addButton("§e원래 이름");
			$form->sendToPlayer($sender);
			break;
		}
		
		return true;
	}
	
	public function changenick($player){
		$form = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createCustomForm(function (Player $player, $data = null){
				$result = $data;
				if($result === null){
					return true;
				}
				if($result != null){
					$this->nickcfg->setNested($player->getName() . ".custom name", $data[0]);
					$this->nickcfg->setNested($player->getName() . ".normal name", $player->getName());
					$this->nickcfg->save();
					$player->setDisplayName($this->nickcfg->getNested($player->getName() . ".custom name"));
					$player->setNameTag($this->nickcfg->getNested($player->getName() . ".custom name"));
					$player->sendMessage("§e현제 당신이름은 §c" . $this->nickcfg->getNested($player->getName() . ".custom name"). "§e입니다");
					return true;
				}
		});
		$form->setTitle("§3이름 변경");
		$form->addInput("§3바꿀 이름을 입력하세요:");
		$form->sendToPlayer($player);
		return $form;
	}
	
	
}
